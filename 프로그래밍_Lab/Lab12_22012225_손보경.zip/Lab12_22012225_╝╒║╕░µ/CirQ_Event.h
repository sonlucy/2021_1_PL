#ifndef CIRCULAR_QUEUE_H
#define CIRCULAR_QUEUE_H
#include <mutex>
#include "Event.h"
using namespace std;
typedef struct
{
	Event* CirBuff_Ev; // circular queue for events
	int capacity;
	int front;
	int end;
	int num_elements;
	mutex mtx_CirBuf;

} CirQ_Event;

CirQ_Event* initCirQ_Event(CirQ_Event* pCirQ, int capacity);
void printCirQ_Event(CirQ_Event* cirQ);
bool isCirQ_Ev_Full(CirQ_Event* cirQ);
bool isCirQ_Ev_Empty(CirQ_Event* cirQ);
Event* enCirQ_Event(CirQ_Event* cirQ, Event ev);
Event* deCirQ_Event(CirQ_Event* cirQ);
void delCirQ_Event(CirQ_Event* cirQ);

#endif