#include <Windows.h>
#include <time.h>
#include "Thread.h"
#include "PriQ_Event.h"
#include "Event.h"

void Thread_EventHandler(ThreadParam_Event* pParam)
{
	Event* pEv, * pEvProc, ev;
	int myRole = pParam->role;
	int myAddr = pParam->myAddr;
	PriQ_Event* pPriQ_Event = pParam->pPriQ_Event;
	ThreadStatusMonitor* pThrdMon = pParam->pThrdMon;
	int maxRound = pParam->maxRound;
	int targetEventGen = pParam->targetEventGen;

	srand(time(NULL));
	for (int round = 0; round < maxRound; round++)
	{
		if (*pThrdMon->pFlagThreadTerminate == TERMINATE)
			break;  //����
		//else
		if ((pEv = dePriQ_Event(pPriQ_Event)) != NULL)  //������� ������
		{
			//printf("Thread_EventProc::deLL_EventQ_from_HighPri_LL_EventQ : ");
			//printEvent(pEv);
			//printf("\n");
			pParam->pMTX_thrd_mon->lock();  //lock
			QueryPerformanceCounter(&pEv->ev_t_handle);  //
			pEv->ev_handler = myAddr;
			pThrdMon->eventProcessed[pThrdMon->totalEventProcessed] = *pEv;  //ó���� ������� ����ǵ���
			pThrdMon->numEventProcessed++;
			pThrdMon->totalEventProcessed++;
			pParam->pMTX_thrd_mon->unlock();  //unlock
			free(pEv);
		}
		Sleep(100 + rand() % 300);
	}
}