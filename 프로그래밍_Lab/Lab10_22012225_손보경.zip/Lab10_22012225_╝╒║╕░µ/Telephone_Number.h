
#ifndef TELEPHONE_NUMBER_H
#define TELEPHONE_NUMBER_H
#define U_SHORT unsigned short

typedef struct
{
	/* unsigned short */
	U_SHORT nation_code;  //������ȣ
	U_SHORT region_no;  //������ȣ
	U_SHORT swith_no;
	U_SHORT line_no;
} Tel_Number;

void printTelephoneNumber(Tel_Number telNo);
//int compareTelNumber(Tel_Number tn1, Tel_Number tn2);
#endif
