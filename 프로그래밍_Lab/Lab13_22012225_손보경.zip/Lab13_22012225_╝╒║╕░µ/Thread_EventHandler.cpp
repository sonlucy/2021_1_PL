#include <Windows.h>
#include <time.h>
#include "Thread.h"
#include "DLL_EvQ.h"
#include "Event.h"
void Thread_EventHandler(ThreadParam_Ev* pThrdParam)
{
	//EventQ* pEvQ;
	DLL_EvQ* pEvQ;

	THREAD_FLAG* pFlagThreadTerminate;
	Event* pEvent;
	int event_id = 0, event_pri = 0, pkt_gen_count = 0;
	int num_event_processed = 0;
	int myRole = pThrdParam->role;
	int myAddr = pThrdParam->myAddr;  ////
	//EventQ* pPriH_LLQ = pThrdParam->pPriH_LLQ;
	//EventQ* pPriL_LLQ = pThrdParam->pPriL_LLQ;
	
	DLL_EvQ* pPriH_LLQ = pThrdParam->EvQ_PriH;
	DLL_EvQ* pPriL_LLQ = pThrdParam->EvQ_PriL;

	ThreadStatMon* pThrdMon = pThrdParam->pThrdMon;
	int maxRound = pThrdParam->maxRound;
	Event* pEventProc = pThrdParam->pThrdMon->eventProcessed;
	int targetEventGen = pThrdParam->targetEventGen;
	pThrdParam->pCS_main->lock();
	printf("Thread_EventHandler(%d) : targetEventGen(%d)\n", myAddr, targetEventGen);
	pThrdParam->pCS_main->unlock();

	for (int round = 0; round < maxRound; round++)
	{
		if (*pThrdMon->pFlagThreadTerminate == TERMINATE)  
			break;   //������ ����
		//else
		while ((pEvent = deDLL_EvQ(pPriH_LLQ)) != NULL)  //High pri
		{
			pThrdParam->pCS_thrd_mon->lock();
			pEvent->event_handler_addr = myAddr;  
			QueryPerformanceCounter(&pEvent->t_proc);
			calc_elapsed_time(pEvent, pThrdParam->PC_freq); //�ð�����
			pEventProc[pThrdMon->totalEventProc] = *pEvent; 
			pThrdMon->eventsProc[pThrdParam->myAddr]++;  
			pThrdMon->totalEventProc++;   
			pThrdMon->numEventProcs_priH++;
			num_event_processed++;
			free(pEvent); // free the memory space for a Event
			pThrdParam->pCS_thrd_mon->unlock();  //
			Sleep(100 + rand() % 300); //���� 100~399
		} // end while
		if ((pEvent = deDLL_EvQ(pPriL_LLQ)) != NULL)  //Low pri
		{
			pThrdParam->pCS_thrd_mon->lock();
			QueryPerformanceCounter(&pEvent->t_proc);
			calc_elapsed_time(pEvent, pThrdParam->PC_freq);  //�ð�����
			pEventProc[pThrdMon->totalEventProc] = *pEvent; 
			pThrdMon->eventsProc[pThrdParam->myAddr]++;  
			pThrdMon->totalEventProc++; 
			pThrdMon->numEventProcs_priL++;
			num_event_processed++;
			free(pEvent);
			pThrdParam->pCS_thrd_mon->unlock();
		} // end if
		Sleep(100 + rand() % 300);  //���� 100~399
	} // end for
}
