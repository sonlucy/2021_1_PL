/* Thread_EventGen.cpp (1) */
#include <Windows.h>
#include <time.h>
#include <thread>
#include <mutex>
#include "Thread.h"
#include "DLL_EvQ.h"
#include "Event.h"
using namespace std;
void Thread_EventGenerator(ThreadParam_Ev* pThrdParam)
{
	DLL_EvQ* pEvQ;
	Event* pEv;
	int event_id = 0, event_pri = 0, event_gen_count = 0;
	int num_event_generated = 1;
	int event_handlerAddr;
	int myRole = pThrdParam->role;
	int myAddr = pThrdParam->myAddr;
	DLL_EvQ* pPriH_LLQ = pThrdParam->EvQ_PriH;
	DLL_EvQ* pPriL_LLQ = pThrdParam->EvQ_PriL;
	int maxRound = pThrdParam->maxRound;
	int targetEventGen = pThrdParam->targetEventGen;
	ThreadStatMon* pThrdMon = pThrdParam->pThrdMon;  //////

	pThrdParam->pCS_main->lock();
	printf("Thread_EventGenerator(%d) : targetEventGen(%d)\n", myAddr, targetEventGen);
	pThrdParam->pCS_main->unlock();

	for (int round = 0; round < maxRound; round++)
	{
		if (event_gen_count >= targetEventGen)  //��ǥ�̺�Ʈ�����̸�
		{
			if (*pThrdMon->pFlagThreadTerminate == TERMINATE)  
				break;  //����
			else {   //Treminate�� �ƴϸ�
				Sleep(500);  //sleep . . .
				continue;
			}
		}
		pEv = (Event*)calloc(1, sizeof(Event));  //�̺�Ʈ ����
		pEv->event_gen_addr = myAddr;
		//pEv->event_handler_addr=event_handlerAddr=rand()% NUM_ROUTERS;
		pEv->event_handler_addr = -1;
		pEv->event_no = event_gen_count;
		pEv->event_pri = event_pri = rand() % NUM_PRIORITY; // 0 ~ 9
		QueryPerformanceCounter(&pEv->t_gen);
		pEvQ = (event_pri < PRIORITY_THRESHOLD) ? pPriH_LLQ : pPriL_LLQ;
		while (enDLL_EvQ(pEvQ, pEv) == NULL)
		{
			Sleep(100);
		} // end while
		
		pThrdParam->pCS_thrd_mon->lock();//
		pThrdMon->eventsGen[myAddr]++;  
		pThrdMon->totalEventGen++;
		pThrdParam->pCS_thrd_mon->unlock(); //
		event_gen_count++;
		num_event_generated++;
		Sleep(100 + rand() % 100);  //100~199
	} // end for
}